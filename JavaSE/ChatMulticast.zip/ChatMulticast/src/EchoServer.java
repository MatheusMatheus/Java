import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class EchoServer extends Thread {
	private DatagramSocket socket;
	private boolean rodando;
	private byte[] buf = new byte[256];

	public EchoServer() {
		try {
			socket = new DatagramSocket(12345);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void run() {
		rodando = true;

		while (rodando) {
			try {
				DatagramPacket pacote = new DatagramPacket(buf, buf.length);
				socket.receive(pacote);
				InetAddress endereco = pacote.getAddress();
				int porta = pacote.getPort();
				pacote = new DatagramPacket(buf, buf.length, endereco, porta);
				String msgRecebida = new String(pacote.getData(), 0, pacote.getLength());
				System.out.println("Mensagem recebida: " + msgRecebida);
				if (msgRecebida.equals("end")) {
					rodando = false;
				}
				socket.send(pacote);
			} catch (IOException e) {
				// TODO: handle exception
			}
		}
		socket.close();
	}
}
