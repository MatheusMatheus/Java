
public class Teste {
    EchoClient client;
    
	public Teste() {
		new EchoServer().start();
		client = new EchoClient();
	}
	
	public static void main(String[] args) {
		Teste teste = new Teste();

		String echo = teste.client.sendEcho("Olá servidor");
        
        echo = teste.client.sendEcho("Servidor 100%");
        
        teste.client.sendEcho("end");
        teste.client.close();
	}
}
